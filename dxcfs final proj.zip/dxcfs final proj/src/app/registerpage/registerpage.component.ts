import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StoreUser } from '../model/User';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-registerpage',
  templateUrl: './registerpage.component.html',
  styleUrls: ['./registerpage.component.css']
})
export class RegisterpageComponent implements OnInit {

  constructor(private router:Router,private daosrv:HttpClientService) { }
uID:number;
uName:string;
pass:string;
Type:string;
Address:string;
Phnno:string;
Pincode:string;

//storeuser:StoreUser={"uID":0,"uName":"","pass":"" ,"type":"","address":"","phnno":"","pincode":""};
storeUser=new StoreUser();

  saverest()
  {
  if (this.uID==null || this.uName==null || this.pass==null || this.Type==null || this.Address==null || this.Phnno==null || this.Pincode==null) 
  {
    alert("All Details Need to be Filled");
  } else {
    if(this.uID!=null && this.uName!=null && this.pass!=null && this.Type!=null && this.Address!=null && this.Phnno!=null && this.Pincode!=null)
  {  
  this.storeUser={"id":this.uID,"name":this.uName,"password":this.pass,"type":this.Type,"address":this.Address,"phnno":this.Phnno,"pincode":this.Pincode};
  this.daosrv.saverest(this.storeUser).subscribe(
  data=>console.log(data),
  error=>console.log(error)
  );
  this.router.navigate(['/login']);
  alert("Successfully Registered");
  }
      
  }

}

  
ngOnInit(): void 
{}

}