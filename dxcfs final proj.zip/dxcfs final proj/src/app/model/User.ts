export class StoreUser {
  id: number;
  name: string;
  type: string;  
  password: string;
  address: string;
  phnno: string;
  pincode:string;

  }