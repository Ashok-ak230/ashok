export class StoreBook {
    id: number;
    name: string;
    author: string;
    price: number;
    picByte: string; 
    retrievedImage: string; 
    isAdded: boolean; 
    }