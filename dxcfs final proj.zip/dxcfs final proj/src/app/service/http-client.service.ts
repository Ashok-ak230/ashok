import { Injectable } from '@angular/core';
import { StoreUser } from '../model/User';
import { HttpClient } from '@angular/common/http';
import { StoreBook } from '../model/Book';

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {
  [x: string]: any;

  constructor(
    private httpClient:HttpClient
  ) { }
  saverest(storeUser:StoreUser)
  {
  
   return this.httpClient.post<StoreUser>('http://localhost:1112/saverest',storeUser); 
  }
  getAll()
  {
    console.log('Getting all users');
    return this.httpClient.get<StoreUser[]>(`http://localhost:1112/rest`);
  }

  getDetail(name:string)
  {
    return this.httpClient.get<StoreUser>(`http://localhost:1112/search/${name}`)
  }
  addUser(newUser: StoreUser) {
    return this.httpClient.post<StoreUser>(`http://localhost:1112/add`, newUser);   
  }
  delUser(name) {
    return this.httpClient.delete<StoreUser>(`http://localhost:1112/del/` + name);
  }
  getAllbooks()
  {
    console.log('Getting all books');
    return this.httpClient.get<StoreBook[]>(`http://localhost:1112/restbook`);
  }
  addBook(newBook: StoreBook) {
    return this.httpClient.post<StoreBook>(`http://localhost:1112/addbook`, newBook);
  }
  delBook(name) {
    return this.httpClient.delete<StoreBook>(`http://localhost:1112/delbook/` + name);
  }
  ItemsInCart:any=[];

addToCart(bookObj)
{
  
this.ItemsInCart.push(bookObj); 
}

getCart()
{

  return this.ItemsInCart;
}

delteItemsInCart(i)
{
//remove item from the given post
this.ItemsInCart.splice(i,1);
console.log(this.ItemsInCart.length);
//this.sum();
return this.ItemsInCart

}

}
