import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StoreUser } from '../model/User';
import { HttpClientService } from '../service/http-client.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
    uName: string;
    pass: string;
    msg;
    constructor(private router:Router,private daosrv:HttpClientService) { }
storeUser=new StoreUser();
  
  loginValidate()
    {
   this.daosrv.getDetail(this.uName).subscribe(
   data=>{this.storeUser=data;  
    let a='hello';

  if(this.uName==this.storeUser.name && this.pass==this.storeUser.password) 
  {
    this.router.navigate(['/shops'])
  }
},
error=>
{
  if (this.uName=="admin" && this.pass=="admin") {
  this.router.navigate(['/shop'])

}
 else
{
console.log(error)
alert('Invalid Login details')
}
}
);

}

ngOnInit() {
}
reguser()
{
this.router.navigate(['registerpage']);
}
}
