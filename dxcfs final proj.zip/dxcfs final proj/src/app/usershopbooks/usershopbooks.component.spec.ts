import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsershopbooksComponent } from './usershopbooks.component';

describe('UsershopbooksComponent', () => {
  let component: UsershopbooksComponent;
  let fixture: ComponentFixture<UsershopbooksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsershopbooksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsershopbooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
