import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BooksComponent } from './admin/books/books.component';
import { UsersComponent } from './admin/users/users.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { ShopbookComponent } from './shopbook/shopbook.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
import { UsershopbooksComponent } from './usershopbooks/usershopbooks.component';
import { UsercartComponent } from './usercart/usercart.component';
import { PaymentComponent } from './payment/payment.component';
import { DisplaydetailsComponent } from './displaydetails/displaydetails.component';
import { RegisterpageComponent } from './registerpage/registerpage.component';

const routes: Routes = [
  {path:'', redirectTo:'login',pathMatch:'full'},
  {path:'login',component:LoginpageComponent},
  { path: 'viewcart', component: ViewcartComponent },
  { path: 'admin/users', component: UsersComponent },
  { path: 'admin/books', component: BooksComponent },
  { path: 'shop', component: ShopbookComponent },
  { path: 'shops', component: UsershopbooksComponent },
  { path: 'viewcarts', component: UsercartComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'displaydetails', component: DisplaydetailsComponent},
  { path: 'registerpage', component: RegisterpageComponent }
  

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
