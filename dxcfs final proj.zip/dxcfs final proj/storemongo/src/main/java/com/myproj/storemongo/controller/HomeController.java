package com.myproj.storemongo.controller;

import java.awt.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.myproj.storemongo.dao.StoreUserDao;
import com.myproj.storemongo.model.StoreUser;

@CrossOrigin
@RestController
public class HomeController {
	@Autowired
	StoreUserDao dao;

	@PostMapping("saverest")
	public StoreUser saveUser(@RequestBody StoreUser storeuser)
	{

	return dao.saveUser(storeuser);

	}
	@GetMapping("rest")
	public ArrayList<StoreUser> getusers()
	{

	return dao.getAll();

	}
	@PostMapping("add")
	public StoreUser createUser(@RequestBody StoreUser storeuser)
	{
	return dao.createUser(storeuser);
	}
	
	
	@GetMapping(value="search/{name}")
	public Object getUser(@PathVariable String name )
	{
		System.out.print(name);
		return dao.getUserById(name); 
		
	}
	
	@DeleteMapping(value="del/{name}")
	public Object DelUser(@PathVariable String name )
	{
		
		return dao.DelUser(name); 
		
	}
	
}
