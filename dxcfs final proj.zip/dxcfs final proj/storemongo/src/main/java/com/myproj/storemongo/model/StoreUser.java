package com.myproj.storemongo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class StoreUser {
	@Id
	int id;
	String name;
	String password;
	String type;
	String address;
	String phnno;
	String pincode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhnno() {
		return phnno;
	}
	public void setPhnno(String phnno) {
		this.phnno = phnno;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
public StoreUser() {
	// TODO Auto-generated constructor stub
}
public StoreUser(int id, String name, String password, String type, String address, String phnno, String pincode) {
	super();
	this.id = id;
	this.name = name;
	this.password = password;
	this.type = type;
	this.address = address;
	this.phnno = phnno;
	this.pincode = pincode;
}
@Override
public String toString() {
	return "StoreUser [id=" + id + ", name=" + name + ", password=" + password + ", type=" + type + ", Address="
			+ address + ", phnno=" + phnno + ", pincode=" + pincode + "]";
}
}
	