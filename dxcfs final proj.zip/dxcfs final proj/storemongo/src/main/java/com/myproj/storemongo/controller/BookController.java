package com.myproj.storemongo.controller;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.myproj.storemongo.dao.StoreBookDao;
import com.myproj.storemongo.model.StoreBook;



@CrossOrigin
@RestController
public class BookController {
	private byte[] bytes;
	@Autowired
	StoreBookDao dao;

	@PostMapping("savebook")
	public StoreBook saveUser(@RequestBody StoreBook storebook)
	{

	return dao.saveBook(storebook);

	}
	@GetMapping("restbook")
	public ArrayList<StoreBook> getbooks()
	{

	return dao.getAllbooks();

	}
	/*@PostMapping("addbook")
	public StoreBook createBook(@RequestBody StoreBook storebook)
	{
	return dao.createBook(storebook);
	}*/
	
	@PostMapping("upload")
	public void uploadImage(@RequestParam("imageFile") MultipartFile file) throws IOException {
		this.bytes = file.getBytes();
	}

	@PostMapping("addbook")
	public void createBook(@RequestBody StoreBook storebook) throws IOException {
		storebook.setPicByte(this.bytes);
		dao.createBook(storebook);
		this.bytes = null;
	}
	
	@PutMapping("update")
	public void updateBook(@RequestBody StoreBook storebook) {
		dao.UpdateBook(storebook);
	}
	
	@DeleteMapping(value="delbook/{name}")
	public Object DelBook(@PathVariable String name )
	{
		
		return dao.DelBook(name); 
		
	}

}
