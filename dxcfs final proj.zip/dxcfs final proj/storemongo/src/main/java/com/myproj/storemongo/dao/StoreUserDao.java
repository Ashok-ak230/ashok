package com.myproj.storemongo.dao;

import java.awt.List;

import java.util.ArrayList;

//import javax.management.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.mongodb.client.result.DeleteResult;
import com.myproj.storemongo.model.StoreUser;


import org.springframework.data.mongodb.core.query.Update;

@Component
public class StoreUserDao {
	@Autowired
	MongoTemplate mongoTemplate;


	public StoreUser saveUser(StoreUser storeuser)
	{
	try
	{
	mongoTemplate.save(storeuser);
	return storeuser;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	
	
	public ArrayList<StoreUser> getAll()
	{

	return (ArrayList<StoreUser>) mongoTemplate.findAll(StoreUser.class);

	}
	
	public StoreUser createUser(StoreUser storeuser)
	{
	try
	{
	mongoTemplate.save(storeuser);
	return storeuser;

	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	
	public StoreUser delUser(StoreUser storeuser)
	{
	try
	{
	mongoTemplate.remove(storeuser);
	return storeuser;
	}
	catch (Exception e) {
	e.printStackTrace();

	}
	return null;

	}
	
	public Object getUserById(String name) {
		Query query = new Query();
		query.addCriteria(Criteria.where("name").is(name));
		StoreUser storeuser= mongoTemplate.findOne(query,StoreUser.class);
		if(storeuser!=null)
		{
			return storeuser;
		}
		return "Invalid User";
	}
	
	public Object DelUser(String name)
	{
		Query query=new Query(Criteria.where("name").is(name));
		DeleteResult storeuser= mongoTemplate.remove(query,StoreUser.class);
	    if(storeuser!=null)
		{
			return storeuser;
		}
		return "no data Found";
	}


	}

	
	
	


